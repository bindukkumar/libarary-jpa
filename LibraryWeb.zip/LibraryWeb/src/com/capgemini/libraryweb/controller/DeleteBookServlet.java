package com.capgemini.libraryweb.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.libraryweb.dao.BookDao;
import com.capgemini.libraryweb.dao.IBookDao;
import com.capgemini.libraryweb.model.Books;


@WebServlet("/delete")
public class DeleteBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IBookDao bookDao;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		bookDao =new BookDao();
		Integer bookId = Integer.parseInt(request.getParameter("id"));
		bookDao.deleteBook(bookId);
		
	}

}
