package com.capgemini.libraryweb.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.libraryweb.dao.BookDao;
import com.capgemini.libraryweb.model.Books;


@WebServlet("/update")
public class UpdateBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookDao bookDao = new BookDao();
		Integer bookId = Integer.parseInt(request.getParameter("id"));
		String bookName=request.getParameter("name");
		String bookAuthor=request.getParameter("author");
		String bookPublisher=request.getParameter("publisher");
		
		Books books = new Books(bookId, bookName, bookAuthor, bookPublisher);
		
		bookDao.updateBook(books);
		
	}

}
