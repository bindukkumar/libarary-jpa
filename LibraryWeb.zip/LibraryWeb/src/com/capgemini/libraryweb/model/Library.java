package com.capgemini.libraryweb.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Library {
	
	@Id
	private int libId;
	private int libName;
	
	Library(){}
	
	public Library(int libId, int libName) {
		super();
		this.libId = libId;
		this.libName = libName;
	}

	@Override
	public String toString() {
		return "Library [libId=" + libId + ", libName=" + libName + "]";
	}

	public int getLibId() {
		return libId;
	}

	public void setLibId(int libId) {
		this.libId = libId;
	}

	public int getLibName() {
		return libName;
	}

	public void setLibName(int libName) {
		this.libName = libName;
	}
	
	
	
	
	

}
