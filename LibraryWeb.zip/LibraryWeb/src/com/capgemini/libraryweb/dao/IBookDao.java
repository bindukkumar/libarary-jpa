package com.capgemini.libraryweb.dao;

import com.capgemini.libraryweb.model.Books;

public interface IBookDao {
	public void addBook(Books books);
	public boolean updateBook(Books books);
	public boolean deleteBook(int bookId);
}
