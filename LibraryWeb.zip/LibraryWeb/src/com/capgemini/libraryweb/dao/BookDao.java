package com.capgemini.libraryweb.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import com.capgemini.libraryweb.model.Books;

public class BookDao implements IBookDao{

	EntityManagerFactory entityManagerFactory=null;
	EntityManager entityManager =null;
	EntityTransaction entityTransaction = null;
	
	
	@Override
	public void addBook(Books books) {
		entityManagerFactory =Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction =entityManager.getTransaction();
		entityTransaction.begin();
		try {
			entityManager.persist(books);
			entityTransaction.commit();
			entityManager.close();
		}catch(Exception e) {
			entityTransaction.rollback();
			e.printStackTrace();
		}
		
	}


	@Override
	public boolean updateBook(Books books) {
		entityManagerFactory =Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction =entityManager.getTransaction();
		entityTransaction.begin();
		try {
			Books book=entityManager.find(Books.class, books.getBookId());
			if(book!=null) {
				book.setBookAuthor(books.getBookAuthor());
				book.setBookName(books.getBookName());
				book.setBookPublisher(books.getBookPublisher());
				entityTransaction.commit();
				entityManager.close();
				return true;
			}
		}catch(Exception e) {
			entityTransaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		return false;
	}


	@Override
	public boolean deleteBook(int  bookId) {
		entityManagerFactory =Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction =entityManager.getTransaction();
		entityTransaction.begin();
		try {
			Books book = entityManager.find(Books.class, bookId);
			entityManager.remove(book);
			entityTransaction.commit();
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			entityTransaction.rollback();
		}
		entityManager.close();
		return false;
	}
	
	
}
